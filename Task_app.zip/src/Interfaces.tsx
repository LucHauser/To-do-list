export default interface ITask{
    id: number | null;
    title: string;
    completed: boolean;
}